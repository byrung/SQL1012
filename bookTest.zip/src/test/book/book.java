package test.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;   
import java.sql.ResultSet;

public class book {
   //연결하기 위해 필요한 정보(url,user, pwd)
         String url = "jdbc:oracle:thin:@localhost:1521:xe";
         String user = "c##madang";
         String pwd = "madang";
         public void runSQL() {
            String sql = "select bookid, bookname from book order by bookid asc;";
         
            try {
               //Connection 객체를 사용해서 문장 객체를 생성
               Statement stmt = con.createStatement();
               //Statement 객체를 사용해서 SQL문을 실행
               ResultSet rs = stmt.executeQuery(sql);
               //next() 메소드는 데이터행을 접근할 수 있는 커서를 다음 행으로 이동 시키는 기능을 한다.
               while(rs.next()) {
                  System.out.print("\t"+rs.getInt("bookid"));
                  System.out.print("\t"+rs.getString("bookname"));
                  System.out.println("------------------------------------------------");
                  
               }
               con.close();
            } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
   Connection con;
   public book(){
      //jdbc driver load 문장   
      
   try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      System.out.println("드라이버 로드 성공");
      con = DriverManager.getConnection(url,user,pwd);
      System.err.println("데이터 베이스 연결 성공");
   } catch (ClassNotFoundException e) {
      // TODO: handle exception
   e.printStackTrace();
   } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
   }
   
}

   public static void main(String[] args) {
      BookList blist = new BookList();
      blist.runSQL();
   }

}

/*
 Class forName("클래스 이름") JDBC 드라이버를 로딩
 DriverManager Connection getConnection(url,user,password) 커넥션 객체 생성
  */
 