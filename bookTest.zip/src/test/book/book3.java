package test.book;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class book3 {
    String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    String USER = "c##madang";
    String PWD = "madang";
    Connection con;

    public book3() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("드라이버 로드 성공");

            con = DriverManager.getConnection(URL, USER, PWD);
            System.out.println("DB 연결 성공");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void runSQL(String searchTerm, int searchMenu) {
        String sql = "SELECT o.*, c.custname FROM orders o LEFT JOIN customer c ON o.custid = c.custid";
        

        if (searchMenu == 1) {
            sql += " WHERE bookname like ?";
        } else if (searchMenu == 2) {
            sql += " WHERE custname like ?";
        } else {
            System.out.println("잘못된 검색 메뉴 선택입니다.");
            return;
        }

        sql += " ORDER BY custname";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, "%" + searchTerm + "%"); // 검색어를 부분 문자열로 랩핑
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                System.out.print("\t" + rs.getString("custname"));
                System.out.print("\t" + rs.getString("bookname"));
                System.out.println("\t" + rs.getInt("saleprice"));
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        book3 bList = new book3();
        Scanner scan = new Scanner(System.in);

        System.out.println("검색 메뉴를 선택하세요 (1: 도서명, 2: 고객명):");
        int searchMenu = scan.nextInt();

        if (searchMenu != 1 && searchMenu != 2) {
            System.out.println("잘못된 검색 메뉴 선택입니다.");
            return;
        }

        System.out.println("검색어를 입력하세요:");
        String searchTerm = scan.next();

        bList.runSQL(searchTerm, searchMenu);

        scan.close();
    }
}
